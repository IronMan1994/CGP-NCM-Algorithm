package PSO_Resources;

public class Particle_Index
{
	public Particle speciesIndividual;
	public int index;
	
	public Particle_Index(Particle temp, int index)
	{
		this.speciesIndividual = temp;
		this.index = index;
	}
	public Particle_Index()
	{
		
	}
}

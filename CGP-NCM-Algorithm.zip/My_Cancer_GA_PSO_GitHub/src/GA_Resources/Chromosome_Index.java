package GA_Resources;

public class Chromosome_Index
{
	public Chromosome speciesIndividual;
	public int index;
	public double Index123;
	
	public Chromosome_Index(Chromosome temp, int index, double Index123)
	{
		this.speciesIndividual = temp;
		this.index = index;
		this.Index123 = Index123;
	}
	public Chromosome_Index()
	{
		
	}
	
}

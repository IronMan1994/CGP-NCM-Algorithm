package GA_Resources;

import java.util.List;

public class FileToList
{
	//每个患者的基因
	public List<float[]> A;
	
	public FileToList(List<float[]> a)
	{
		this.A = a;
	}
	
	public FileToList()
	{
		
	}
}
